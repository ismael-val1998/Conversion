# Projet conversion

1.  ##  But du projet

    -   Créer un module python
    -   Le puplier sur la communaité de python (Pypi.org)

2.  ##  Etapes

    -   Création de compte sur github
    -   Création de compte sur Pypi.org
    -   Developpement du module
    -   Confirguration necessaire 
    -   installation du package créer avec la commande pip

3.  ##  Utilité du module
    
    Le module conversion permet de convertir une vitesse soit : 

    -   En Kilomètre par heure (Km/h)
    -   En mètre par séconde (m/s)

4.  ##  Lancement du module

    -   on founir en entrée la vitesse 
    -   on lance le programme : conversion ( vitesse )
