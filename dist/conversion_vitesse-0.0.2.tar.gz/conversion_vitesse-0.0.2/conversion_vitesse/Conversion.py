def Conversion_Vitesse_kmH(vitesse):
    initial_vitesse = vitesse
    final_vitesse = initial_vitesse * 3.6
    float(final_vitesse)
    return final_vitesse

def Conversion_Vitesse_mS(vitesse):
    initial_vitesse = vitesse
    final_vitesse = initial_vitesse / 3.6
    float(final_vitesse)
    return final_vitesse

